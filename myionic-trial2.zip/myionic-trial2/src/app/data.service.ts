import { Observable } from 'rxjs/Rx';
import 'rxjs/Rx';
import { Http, Headers, Response, Jsonp, RequestOptions } from '@angular/http';
import { Injectable } from '@angular/core';
import  { UserInfo} from './UserInfo';

import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/catch';
@Injectable()
export class DataserviceService {
  result:UserInfo[];
  constructor(private http:Http) { }

 getDatalist(): Observable<UserInfo[]>   {
    let response$=this.http.get('http://localhost/APIWeb/api/data/GetList').map(this.extractData);
 
    //let subs$=response$.subscribe(res:Response=>{console.log(res);});

//     let subs$ = response$
// .subscribe((res:Response)=> {
// console.log(res);

// });
  return  response$;
}

 
 getJsonDataList(): Observable<any>   {
    let response$=this.http.get('assets/data.json')
                        .map(this.extractData)
    console.log('result='+this.result);

  return response$;
}

  private extractData(res:Response){
    let body= res.json();
 
    console.log('body='+body);
    
    return body || {};
  }
}
