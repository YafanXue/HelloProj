export  class UserInfo{

    userGuid:string;
    account:string;
    name:string;
    email:string;
    language:string;
    icon:string;
}