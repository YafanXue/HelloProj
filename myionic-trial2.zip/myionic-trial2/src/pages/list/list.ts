
import { Component } from '@angular/core';

import { Loading, NavController, NavParams } from 'ionic-angular';

import { ItemDetailsPage } from '../item-details/item-details';
import { UserInfo} from '../../app/UserInfo';
import { DataserviceService} from '../../app/data.service';
import { LoadingController } from 'ionic-angular';
const ORGITEMS: UserInfo[]= [
    {userGuid:'b1',account:'baby use',name:'測是員一',email:'test@yahoo.com.tw',language:'',icon:''},
    {userGuid:'b2',account:'my favorite book',name:'測試員二',email:'test@yahoo.com.tw',language:'',icon:''},
    {userGuid:'b3',account:'life neead',name:'測試員三',email:'test@yahoo.com.tw',language:'',icon:''}
  ];   
@Component({
  selector: 'page-list',
  templateUrl: 'list.html'
})
export class ListPage {
  icons: string[];
  items: Array<{title: string, note: string, icon: string}>;
  userdata:UserInfo[];
  dataitems=ORGITEMS;

  //這裡是建構是和注入服務的地方
  constructor(public navCtrl: NavController, public navParams: NavParams,public loadingCtrl: LoadingController,private service:DataserviceService) {
    //設定列表的icon圖檔
    this.icons = ['flask', 'wifi', 'beer', 'football', 'basketball', 'paper-plane',
    'american-football', 'boat', 'bluetooth', 'build'];

    //設定loading
 let loader = this.loadingCtrl.create({
      content: "Please wait..."
    });
    loader.present();

    //原本的範例先註解**************************
    // this.items = [];
    // for(let i = 1; i < 11; i++) {
    //   this.items.push({
    //     title: 'Item ' + i,
    //     note: 'This is item #' + i,
    //     icon: this.icons[Math.floor(Math.random() * this.icons.length)]
    //   });
    // }
    //*******************************************  */

    //這個是透過固定的UserInfo陣列去BIND畫面,dataitems就是UserInfo的陣列內容************
    for(let j of this.dataitems){
      j.icon= this.icons[Math.floor(Math.random() * this.icons.length)];
    }
    loader.dismiss();
    console.log('orgitem='+this.dataitems);
    //--*******************************************************************************

    //這部分是透過http.get的方式取得server上的json檔案內容來做bind**********************
    //  let sub$= this.service.getJsonDataList()
    //                       .subscribe(data=>{this.userdata=data;
    //                         for(let m of this.userdata){
    //   m.icon= this.icons[Math.floor(Math.random() * this.icons.length)];
    // }   });
    //***************************************************************************

    //從webapi取得資料並結束loading************************************************
    //  let sub1$= this.service.getDatalist()
    //                       .subscribe(data=>{ 
    //                         this.userdata=data;
    //                         for(let m of this.userdata){
    //                             m.icon= this.icons[Math.floor(Math.random() * this.icons.length)];          
    //                          } }
    //                          ,err=>{console.log(err)}
    //                          ,()=>{loader.dismiss()}); 

  }
 
  itemTapped(event, item) {
    //點到明細後的動作轉到另一個itemdetailpage也把明細的item傳送過去
    this.navCtrl.push(ItemDetailsPage, {
      item: item
    });
  }

  ngOnDestroy(){
    
  }
}
